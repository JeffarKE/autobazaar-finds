import type { Car } from "@/app/types/car";
import VehicleCard from "./VehicleCard";

interface RelatedCarsProps {
  currentCar: Car;
  cars: Car[];
}

export default function RelatedCars({
  currentCar,
  cars,
}: RelatedCarsProps) {
  const relatedCars = cars
    .filter(
      (car) =>
        car.id !== currentCar.id &&
        (car.make === currentCar.make ||
          car.bodyType === currentCar.bodyType)
    )
    .slice(0, 3);

  if (relatedCars.length === 0) {
    return null;
  }

  return (
    <section className="mt-16">
      <h2 className="mb-6 text-2xl font-bold">
        Similar Vehicles
      </h2>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {relatedCars.map((car) => (
          <VehicleCard
            key={car.id}
            car={car}
          />
        ))}
      </div>
    </section>
  );
}