"use client";

import { useMemo, useState } from "react";
import { Car } from "@/app/data/cars";

export type SortOption =
  | "newest"
  | "oldest"
  | "price-low"
  | "price-high";

export function useCarFilters(cars: Car[]) {
  const [search, setSearch] = useState("");

  const [fuel, setFuel] = useState("");
  const [transmission, setTransmission] = useState("");
  const [bodyType, setBodyType] = useState("");
  const [location, setLocation] = useState("");
  const [status, setStatus] = useState("");

  const [sortBy, setSortBy] =
    useState<SortOption>("newest");

  const filteredCars = useMemo(() => {
    let results = [...cars];

    // ------------------------
    // Search
    // ------------------------

    if (search.trim()) {
      const query = search.trim().toLowerCase();

      results = results.filter((car) =>
        [
          car.make,
          car.model,
          car.engine,
          car.description,
        ]
          .join(" ")
          .toLowerCase()
          .includes(query)
      );
    }

    // ------------------------
    // Filters
    // ------------------------

    if (fuel) {
      results = results.filter((car) => car.fuel === fuel);
    }

    if (transmission) {
      results = results.filter(
        (car) => car.transmission === transmission
      );
    }

    if (bodyType) {
      results = results.filter(
        (car) => car.bodyType === bodyType
      );
    }

    if (location) {
      results = results.filter(
        (car) => car.location === location
      );
    }

    if (status) {
      results = results.filter(
        (car) => car.status === status
      );
    }

    // ------------------------
    // Sorting
    // ------------------------

    switch (sortBy) {
      case "price-low":
        results.sort((a, b) => a.price - b.price);
        break;

      case "price-high":
        results.sort((a, b) => b.price - a.price);
        break;

      case "oldest":
        results.sort((a, b) => a.year - b.year);
        break;

      case "newest":
      default:
        results.sort((a, b) => b.year - a.year);
        break;
    }

    return results;
  }, [
    cars,
    search,
    fuel,
    transmission,
    bodyType,
    location,
    status,
    sortBy,
  ]);

  // ------------------------
  // Dynamic Filter Options
  // ------------------------

  const fuelOptions = useMemo(
    () =>
      [...new Set(cars.map((car) => car.fuel))].sort(),
    [cars]
  );

  const transmissionOptions = useMemo(
    () =>
      [...new Set(cars.map((car) => car.transmission))].sort(),
    [cars]
  );

  const bodyTypeOptions = useMemo(
    () =>
      [...new Set(cars.map((car) => car.bodyType))].sort(),
    [cars]
  );

  const locationOptions = useMemo(
    () =>
      [...new Set(cars.map((car) => car.location))].sort(),
    [cars]
  );

  const statusOptions = useMemo(
    () =>
      [...new Set(cars.map((car) => car.status).filter(Boolean))].sort() as (
        | "available"
        | "featured"
        | "sold"
      )[],
    [cars]
  );

  function clearFilters() {
    setSearch("");
    setFuel("");
    setTransmission("");
    setBodyType("");
    setLocation("");
    setStatus("");
    setSortBy("newest");
  }

  return {
    filteredCars,

    // Dynamic Options
    fuelOptions,
    transmissionOptions,
    bodyTypeOptions,
    locationOptions,
    statusOptions,

    // Search
    search,
    setSearch,

    // Filters
    fuel,
    setFuel,

    transmission,
    setTransmission,

    bodyType,
    setBodyType,

    location,
    setLocation,

    status,
    setStatus,

    // Sorting
    sortBy,
    setSortBy,

    // Actions
    clearFilters,
  };
}